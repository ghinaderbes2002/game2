import 'package:game2/core/constants/routes.dart';
import 'package:game2/view/screan/addround.dart';
import 'package:game2/view/screan/auth/login.dart';
import 'package:game2/view/screan/auth/signup.dart';
import 'package:game2/view/screan/deleteround.dart';
import 'package:game2/view/screan/exitround.dart';
import 'package:game2/view/screan/maininterface.dart';
import 'package:get/get.dart';

List<GetPage<dynamic>>? routes = [
  GetPage(name: "/", page: () => const Main()),
  GetPage(name: AppRoute.signUp, page: () => const SigUp()),
  GetPage(name: AppRoute.login, page: () => const Login()),
  GetPage(name: AppRoute.deleteround, page: () => const DeleteRound()),
  GetPage(name: AppRoute.exitround, page: () => const ExitRound()),
  GetPage(name: AppRoute.addround, page: () => const AddRound()),
];
