import 'package:get/get.dart';

abstract class RecordController extends GetxController {}

class RecordControllerimp extends RecordController {}
