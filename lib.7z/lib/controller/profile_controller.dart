import 'package:get/get.dart';

abstract class ProfileController extends GetxController {
  signout();
  deleteuser();
}

class ProfileControllerimp extends ProfileController {
  @override
  deleteuser() {

  }

  @override
  signout() {
    
  }
}
