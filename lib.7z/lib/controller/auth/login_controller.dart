import 'package:flutter/material.dart';
import 'package:game2/view/screan/auth/signup.dart';
import 'package:game2/view/screan/maininterface.dart';
import 'package:get/get.dart';

abstract class LoginController extends GetxController {
  Login();
  goToSigUp();
  showPassword();
}

class LoginControllerimp extends LoginController {
  TextEditingController username = TextEditingController();
  TextEditingController password = TextEditingController();

  bool isObsecure = true;

  @override
  Login() {
    Get.offAll(() => Main());
  }

  @override
  goToSigUp() {
    Get.offAll(() => SigUp());
  }

  showPassword() {
    isObsecure = !isObsecure;
    update();
  }
}
