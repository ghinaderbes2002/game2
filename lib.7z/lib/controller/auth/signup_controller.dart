import 'package:flutter/material.dart';
import 'package:game2/core/constants/routes.dart';
import 'package:game2/view/screan/auth/login.dart';
import 'package:get/get.dart';

abstract class SignUpController extends GetxController {
  SigUp();
  goToSigIn();
}

class SignUpControllerimp extends SignUpController {
  TextEditingController password = TextEditingController();
  TextEditingController checkpassword = TextEditingController();
  TextEditingController username = TextEditingController();
  bool isObsecure = true;

  @override
  SigUp() {
    if (password.text.trim() == checkpassword.text.trim()) {
      Get.offAll(() => Login());
    } else {}
  }

  @override
  goToSigIn() {
    Get.offAll(() => Login());
  }
}
