import 'package:get/get.dart';

abstract class MainController extends GetxController {}

class MainControllerimp extends MainController {}
