import 'package:flutter/material.dart';
import 'package:get/get.dart';

abstract class ExitRoundController extends GetxController {}

class ExitRoundControllerimp extends ExitRoundController {
  TextEditingController roundname2 = TextEditingController();
  TextEditingController roundwords = TextEditingController();
}
