class AppRoute {
  static const String login = "/login";
  static const String signUp = "/signUp";
  static const String profile = "/profile";
  static const String addround = "/addround";
    static const String exitround = "/exitround";
     static const String deleteround = "/deleteround";
}
